# HIL-Bench Dataset v0.1-alpha

This is a **candidate pre-ratification dataset pack** aligned with the revised *Unified Intelligence Theory and the Harness Intelligence Level*. It treats the intelligence-level definitions as stable capability predicates and the benchmark items as evidence for those predicates.

**Important:** this pack is not an official HIL-1.0 certification set. The development-private witness tasks and keys are included for research and runner development; once distributed they are no longer private. Official certification requires fresh server-side hidden witness forms.

## Design principle

**New tests can extend evidence; they do not redefine an existing intelligence level.**

The pack therefore separates:
- canonical method IDs (the measurement law),
- public reference instances (readable, permanent candidates),
- development-private witness instances (for testing the evaluator), and
- human-review protocols for high-level tasks where deterministic verification is incomplete.

## Files

- `public/public_reference_tasks.jsonl` — 71 public candidate reference tasks/contracts.
- `public/public_answer_keys.jsonl` — answer keys for fully public deterministic examples.
- `organizer/development_private_witness_tasks.jsonl` — 132 development-private witness forms.
- `organizer/development_private_answer_keys.jsonl` — organizer keys; **not secure once shared**.
- `spec/canonical_methods.json` — canonical measurement-law candidates, including I1 restart, I2 transfer, I3 governed change, I4 meta-improvement, I5 discovery, O0–O3, DI, and SA.
- `schemas/task.schema.json` — permissive JSON schema for task manifests.
- `docs/HUMAN_REVIEW_PROTOCOL.md` — blinded human-review procedure for residual high-level judgments.
- `dataset_summary.csv` — coverage counts by split/coordinate/level/status.

## Current coverage

The dataset intentionally mixes three statuses:
- `BOUND`: directly checkable task or lifecycle item;
- `BOUND_CONTRACT`: runner-executable protocol contract whose lifecycle harness still must be implemented;
- `SPECIFICATION_ONLY`: high-level longitudinal protocol not yet implemented as a complete environment.

The public set emphasizes C0–C5, I0–I3, O0–O3 contracts, DI T0–T4, and SA1–SA5 contracts. I4/I5/IΩ are included as canonical protocol candidates rather than falsely presented as cheap static questions.

## Suggested use

1. Validate schema and item correctness.
2. Implement lifecycle runner operations: checkpoint, kill, restart, resume, ablated control, feedback, candidate-change sandbox, independent promotion.
3. Run the public set for development.
4. Use development-private forms only to debug the evaluator.
5. For official certification, regenerate hidden witness forms server-side and never distribute their keys.

## Candidate reporting

For a singleton pair, report at minimum:

`UI* | HLIS | [C, I, T/H, SA] | reliability | false-completion | resources | form id`

For an organization, add O and organizational validity evidence.
