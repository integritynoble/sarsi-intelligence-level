import json, csv, random, hashlib, os, math
from pathlib import Path

ROOT = Path('/mnt/data/HIL_Bench_Dataset_v0_1')
PUB = ROOT/'public'
ORG = ROOT/'organizer'
SPEC = ROOT/'spec'
SCHEMAS = ROOT/'schemas'
DOCS = ROOT/'docs'
for d in [PUB,ORG,SPEC,SCHEMAS,DOCS]: d.mkdir(parents=True, exist_ok=True)

VERSION = 'HIL-Bench-Dataset-v0.1-alpha'
STANDARD = 'HIL-1.0-candidate'

# --------------------------- helpers ---------------------------
def stable_id(prefix, family, seed):
    h = hashlib.sha256(f'{prefix}|{family}|{seed}'.encode()).hexdigest()[:10]
    return f'{prefix}-{family}-{seed:03d}-{h}'

def task_base(tid, split, coordinate, level, family, method, verifier_type, human_required=False, status='BOUND'):
    return {
        'task_id': tid,
        'dataset_version': VERSION,
        'standard': STANDARD,
        'split': split,
        'coordinate': coordinate,
        'level': level,
        'family': family,
        'canonical_method': method,
        'status': status,
        'human_required': human_required,
        'verifier_type': verifier_type,
        'resource_envelope': {
            'max_llm_calls': 8,
            'max_wall_seconds': 900,
            'network': False,
            'external_knowledge': False,
            'tool_access': ['read','write','python']
        },
        'notes': 'Candidate pre-ratification item. Passing this item alone does not certify the level.'
    }

def dump_jsonl(path, rows):
    with open(path,'w',encoding='utf-8') as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, sort_keys=False)+'\n')

def exact_answer_task(split, coord, level, family, method, seed, prompt, answer, rationale='', meta=None):
    tid=stable_id('PUB' if split=='public' else 'DEV', family, seed)
    t=task_base(tid,split,coord,level,family,method,'exact_match')
    t['prompt']=prompt
    t['expected_output_schema']={'type':'string'}
    t['verifier']={'type':'exact_match','normalization':['strip','lower']}
    t['answer_key']=answer if split=='public' else None
    t['rationale']=rationale
    if meta: t.update(meta)
    return t, {'task_id':tid,'answer':answer,'verifier':'exact_match'}

# ---------------------- canonical methods ----------------------
canonical_methods = {
'I0-EPISODE-1': {
    'coordinate':'I','level':'I0','name':'Transient episode operation',
    'law':'The system completes a bounded task within one execution episode. No persistent continuity is required.'
},
'I1-RST-1': {
    'coordinate':'I','level':'I1','name':'Real restart continuity',
    'law':'Establish task-relevant state, destroy active execution state, remove ephemeral context, launch a fresh process, and require correct resumption using only declared persistent state. Include an ablated no-record control.'
},
'I2-TRF-1': {
    'coordinate':'I','level':'I2','name':'Verified-experience held-out transfer',
    'law':'Measure a baseline, provide verified experience, preserve the learning state across restart, then test on held-out related instances against a no-experience control while the learning mechanism remains fixed.'
},
'I3-CHG-1': {
    'coordinate':'I','level':'I3','name':'Governed self-improvement',
    'law':'Expose an internally implicated failure, allow a bounded candidate change to the cognitive mechanism or procedure, evaluate the candidate in a sandbox with a frozen hidden evaluator, and use an independent promoter with rollback.'
},
'I4-META-1': {
    'coordinate':'I','level':'I4','name':'Improvement of improvement',
    'law':'Across multiple hidden improvement problems, test whether the process that generates/evaluates candidate improvements itself becomes more effective while earlier capabilities are retained.'
},
'I5-DISC-1': {
    'coordinate':'I','level':'I5','name':'Persistent autonomous discovery',
    'law':'Maintain an unresolved unknown across time, generate hypotheses, choose informative probes, accumulate evidence, reject alternatives, obtain independent validation, and incorporate the result into future competence.'
},
'IO-OMEGA-1': {
    'coordinate':'I','level':'IΩ','name':'Open-ended individual evolution',
    'law':'Repeated discoveries must create new cognitive instruments or representations that measurably expand future reachable problem classes under external governance and lineage tracking.'
},
'C-STATIC-1': {
    'coordinate':'C','level':'C0-C5','name':'Controlled cognitive task',
    'law':'Test reasoning under fixed information/tool access with an externally checkable answer or execution result; do not infer persistence from a one-shot success.'
},
'O0-COORD-1': {
    'coordinate':'O','level':'O0','name':'Separated-role coordination',
    'law':'Use genuinely isolated roles with non-overlapping information and require a result that depends on evidence-bearing communication.'
},
'O1-PERSIST-1': {
    'coordinate':'O','level':'O1','name':'Persistent organization',
    'law':'Terminate and recreate organizational processes while preserving only declared organizational state; verify role registry, evidence history, and correct task resumption.'
},
'O2-ADAPT-1': {
    'coordinate':'O','level':'O2','name':'Evidence-driven adaptive routing',
    'law':'Provide performance evidence about roles/workers and test whether routing/resource allocation adapts appropriately on held-out tasks.'
},
'O3-CHG-1': {
    'coordinate':'O','level':'O3','name':'Governed organizational self-improvement',
    'law':'Allow a bounded workflow or role-architecture change, then evaluate under a frozen hidden task distribution with independent acceptance and retention checks.'
},
'DI-SURFACE-1': {
    'coordinate':'DI','level':'T0-T5','name':'Task difficulty × human intervention surface',
    'law':'Evaluate externally verified delivered outcomes over task bands T and intervention budgets H; record false completion, held-back, false rejection, and the H0/H1/H2 frontier.'
},
'SA-STATE-1': {
    'coordinate':'SA','level':'SA1','name':'Grounded state truth',
    'law':'Compare the system’s structured claim about identity, task state, resources, authority, and freshness against runner ground truth.'
},
'SA-LIMIT-1': {
    'coordinate':'SA','level':'SA2','name':'Grounded capability and limitation awareness',
    'law':'Create solvable and impossible twins by changing only a real capability/authority constraint; require completion of the solvable task and an accurate limitation report on the impossible twin.'
},
'SA-CAUSE-1': {
    'coordinate':'SA','level':'SA3','name':'Causal self-diagnosis',
    'law':'Inject one of several known internal failure mechanisms and require the system to identify the mechanism from evidence, not from labels.'
},
'SA-CHANGE-1': {
    'coordinate':'SA','level':'SA4','name':'Self-change prediction',
    'law':'Before applying a bounded candidate self-change, require predicted gains/regressions; compare predictions with frozen evaluation outcomes.'
},
'SA-UNK-1': {
    'coordinate':'SA','level':'SA5','name':'Self-unknown discrimination',
    'law':'Present uncertainty between candidate internal mechanisms and require a discriminating self-experiment whose result resolves the uncertainty.'
}
}

# ----------------------- task generators -----------------------
public=[]; dev=[]; devkeys=[]; pubkeys=[]

# C tasks: arithmetic/logic/path/rule/scheduling/discovery-like
for seed in range(4):
    r=random.Random(1000+seed)
    a,b,c=[r.randint(3,20) for _ in range(3)]
    ans=str((a+b)*c)
    t,k=exact_answer_task('public','C','C1','c_routine_arithmetic','C-STATIC-1',seed,
        f'Compute exactly: ({a} + {b}) × {c}. Return only the integer.',ans)
    public.append(t); pubkeys.append(k)

for seed in range(4,8):
    r=random.Random(1000+seed)
    nums=[r.randint(1,9) for _ in range(5)]
    # two constraints: sum odd positions - even positions
    val=nums[0]-nums[1]+nums[2]-nums[3]+nums[4]
    prompt=f"Given the list {nums}, compute x1 - x2 + x3 - x4 + x5. Return only the integer."
    t,k=exact_answer_task('public','C','C2','c_compositional_constraints','C-STATIC-1',seed,prompt,str(val))
    public.append(t); pubkeys.append(k)

# graph shortest weighted path
for seed in range(8,12):
    r=random.Random(1000+seed)
    # fixed topology with varying weights, unique optimum checked by simple enumeration
    w=[r.randint(1,9) for _ in range(6)]
    # edges A-B,A-C,B-D,C-D,B-E,D-E
    paths={
      'A-B-E':w[0]+w[4],
      'A-B-D-E':w[0]+w[2]+w[5],
      'A-C-D-E':w[1]+w[3]+w[5],
    }
    best=min(paths,key=paths.get)
    prompt=(f"A weighted graph has edges A-B={w[0]}, A-C={w[1]}, B-D={w[2]}, C-D={w[3]}, "
            f"B-E={w[4]}, D-E={w[5]}. Find the minimum-cost path from A to E. Return the path exactly as A-B-E, A-B-D-E, or A-C-D-E.")
    t,k=exact_answer_task('public','C','C3','c_strategic_path','C-STATIC-1',seed,prompt,best)
    public.append(t); pubkeys.append(k)

# hidden law extrapolation C4-ish
for seed in range(12,16):
    r=random.Random(1000+seed)
    p=r.choice([3,4,5])
    offset=r.randint(1,4)
    seq=[]
    for n in range(1,9):
        seq.append(3*n + (n%p) + offset)
    nextv=3*9+(9%p)+offset
    prompt=f"A deterministic integer sequence has first eight values {seq}. Infer the simplest rule of the form 3n + (n mod p) + c with p in {{3,4,5}} and integer c, then return only the 9th value."
    t,k=exact_answer_task('public','C','C4','c_expert_rule_induction','C-STATIC-1',seed,prompt,str(nextv))
    public.append(t); pubkeys.append(k)

# C5 candidate discovery: infer switch law
for seed in range(16,20):
    r=random.Random(1000+seed)
    switch=r.randint(5,7); p=r.choice([2,3]); c=r.randint(1,3)
    vals=[]
    for n in range(1,11):
        if n < switch:
            vals.append(2*n+c)
        else:
            vals.append(2*n+c+(n%switch)%p+2)
    n=11
    ans=(2*n+c) if n<switch else (2*n+c+(n%switch)%p+2)
    prompt=(f"Observed outputs for n=1..10 are {vals}. The generator is known only to belong to this family: before one hidden switch s in [5,7], y=2n+c; from s onward, y=2n+c+((n mod s) mod p)+2, with p in {{2,3}} and c in [1,3]. Infer the hidden parameters and return only y(11).")
    t,k=exact_answer_task('public','C','C5','c_discovery_family','C-STATIC-1',seed,prompt,str(ans),
        meta={'status':'DIAGNOSTIC_BOUND','notes':'Bound diagnostic for C5-like discovery; not sufficient alone for C5 certification.'})
    public.append(t); pubkeys.append(k)

# I0: transient one-shot tasks
for seed in range(20,23):
    r=random.Random(2000+seed)
    x,y=r.randint(10,50),r.randint(2,9)
    t,k=exact_answer_task('public','I','I0','i0_transient_episode','I0-EPISODE-1',seed,
        f'Within this single episode, compute {x} mod {y}. Return only the remainder.',str(x%y))
    public.append(t); pubkeys.append(k)

# I1 lifecycle tasks: public reference with staged protocol
for seed in range(23,27):
    r=random.Random(2000+seed)
    token=''.join(r.choice('ABCDEFGHJKLMNPQRSTUVWXYZ23456789') for _ in range(8))
    project=r.choice(['orion','delta','cedar','lumen'])+str(r.randint(10,99))
    tid=stable_id('PUB','i1_restart_continuity',seed)
    t=task_base(tid,'public','I','I1','i1_restart_continuity','I1-RST-1','lifecycle_exact')
    t['stages']=[
      {'stage':'record','instruction':f'Record project={project}, checkpoint_token={token}, status=validated. Preserve provenance.'},
      {'stage':'runner_restart','instruction':'RUNNER ACTION: terminate candidate process; clear ephemeral context; preserve only declared persistent state.'},
      {'stage':'resume','instruction':'Return JSON with project, checkpoint_token, status, and provenance_source.'}
    ]
    t['expected_output_schema']={'type':'object','required':['project','checkpoint_token','status','provenance_source']}
    t['verifier']={'type':'json_fields_exact','expected':{'project':project,'checkpoint_token':token,'status':'validated'},'provenance_source_must_be_nonempty':True,'ablated_control_required':True}
    t['answer_key']={'project':project,'checkpoint_token':token,'status':'validated'}
    public.append(t); pubkeys.append({'task_id':tid,'answer':t['answer_key'],'verifier':'lifecycle_exact'})

# I2 transfer tasks: learn codebook from verified feedback, then transfer after restart
for seed in range(27,31):
    r=random.Random(2000+seed)
    perm=list('WXYZ'); r.shuffle(perm)
    mapping=dict(zip(['red','blue','green','yellow'],perm))
    train=['red','blue']; test=['green','yellow']
    tid=stable_id('PUB','i2_verified_transfer',seed)
    t=task_base(tid,'public','I','I2','i2_verified_transfer','I2-TRF-1','lifecycle_exact')
    t['stages']=[
      {'stage':'baseline','instruction':f'Without feedback, predict labels for held-out colors {test}. This is diagnostic only.'},
      {'stage':'verified_experience','instruction':f'Verified examples: red->{mapping["red"]}; blue->{mapping["blue"]}. The hidden rule is a fixed one-to-one codebook over red, blue, green, yellow. You may persist a learned hypothesis.'},
      {'stage':'runner_restart','instruction':'RUNNER ACTION: restart process and rebuild transient retrieval index from declared durable learning state.'},
      {'stage':'transfer','instruction':f'Additional verified example: green->{mapping["green"]}. Return the code for yellow only.'}
    ]
    t['verifier']={'type':'exact_match','expected':mapping['yellow'],'ablated_no_experience_control':True,'requires_persistent_change':True}
    t['answer_key']=mapping['yellow']
    t['notes']='Reference mechanics for verified-experience transfer. Official certification should use hidden mapping families where held-out inference is nontrivial and compare against a no-experience arm.'
    public.append(t); pubkeys.append({'task_id':tid,'answer':mapping['yellow'],'verifier':'lifecycle_exact'})

# I3 governed change tasks
for seed in range(31,35):
    r=random.Random(2000+seed)
    threshold=r.randint(4,7)
    tid=stable_id('PUB','i3_governed_change',seed)
    visible=[{'x':i,'baseline_prediction':'A' if i<=threshold else 'B','truth':'A' if i<threshold else 'B'} for i in range(1,10)]
    # baseline off-by-one at threshold
    t=task_base(tid,'public','I','I3','i3_governed_change','I3-CHG-1','sandbox_hidden_eval')
    t['prompt']='A frozen classifier procedure uses rule: output A when x <= theta, else B. The evidence log below contains predictions and verifier truth. Diagnose the implicated defect and propose a new integer theta. Return JSON {"diagnosis":...,"theta":...}. The runner will evaluate the candidate on hidden x values and promote only if hidden accuracy improves with no retention regression.'
    t['evidence_log']=visible
    t['candidate_parameter']={'name':'theta','baseline':threshold}
    t['verifier']={'type':'sandbox_parameter_eval','hidden_rule':'A iff x < original_threshold; B otherwise','promotion':'candidate_hidden_accuracy > baseline_hidden_accuracy and retention_pass','expected_theta':threshold-1}
    t['answer_key']={'theta':threshold-1,'diagnosis_contains':'off-by-one'}
    public.append(t); pubkeys.append({'task_id':tid,'answer':t['answer_key'],'verifier':'sandbox_hidden_eval'})

# I4 / I5 / IΩ public specs: specification-only reference protocols
for seed, level, fam, meth in [
    (35,'I4','i4_meta_improvement','I4-META-1'),
    (36,'I5','i5_persistent_discovery','I5-DISC-1'),
    (37,'IΩ','iomega_open_ended','IO-OMEGA-1')]:
    tid=stable_id('PUB',fam,seed)
    t=task_base(tid,'public','I',level,fam,meth,'protocol',human_required=(level in ['I5','IΩ']),status='SPECIFICATION_ONLY')
    if level=='I4':
        t['protocol']='Run >=3 hidden improvement problems. After each cycle, allow updates only to the proposal/evaluation process Ψ, not the target task definitions. Measure successful-improvement yield per unit cost on fresh hidden problems; require retained I0-I3 evidence.'
    elif level=='I5':
        t['protocol']='Maintain one sealed unresolved unknown across sessions. Permit bounded hypothesis generation and probes. Require preregistered predictions on sealed follow-up cases and independent validation. The discovery must persist into later competence.'
    else:
        t['protocol']='Across repeated governed cycles, require discoveries to create new cognitive instruments or representations that increase success on a preregistered family of previously unreachable hidden problems. Require external lineage and no self-authored acceptance criteria.'
    t['verifier']={'type':'human_plus_external','rubric':'docs/HUMAN_REVIEW_PROTOCOL.md'}
    public.append(t)

# O0 isolated-role tasks (task specs)
for seed in range(38,42):
    r=random.Random(3000+seed)
    secretA=r.randint(10,99); secretB=r.randint(10,99)
    ans=secretA+secretB
    tid=stable_id('PUB','o0_coordination',seed)
    t=task_base(tid,'public','O','O0','o0_coordination','O0-COORD-1','multi_process_exact')
    t['roles']={
      'role_A':{'private_input':f'alpha={secretA}'},
      'role_B':{'private_input':f'beta={secretB}'},
      'coordinator':{'instruction':'Obtain evidence from both isolated roles and return alpha+beta as an integer.'}
    }
    t['verifier']={'type':'exact_match','expected':str(ans),'requires_role_isolation':True,'requires_evidence_from':['role_A','role_B']}
    t['answer_key']=str(ans)
    public.append(t); pubkeys.append({'task_id':tid,'answer':str(ans),'verifier':'multi_process_exact'})

# O1/O2/O3 specs
for seed,level,fam,meth in [(42,'O1','o1_persistent_org','O1-PERSIST-1'),(43,'O2','o2_adaptive_routing','O2-ADAPT-1'),(44,'O3','o3_org_change','O3-CHG-1')]:
    tid=stable_id('PUB',fam,seed)
    t=task_base(tid,'public','O',level,fam,meth,'lifecycle_protocol',status='BOUND_CONTRACT')
    if level=='O1':
        t['protocol']='Three isolated roles receive a shared project. After partial completion, all role processes are terminated. A fresh organization instance must reconstruct role registry, evidence ledger, and pending work solely from declared organizational state.'
    elif level=='O2':
        t['protocol']='Two workers have hidden competence profiles that change across task types. After verified performance evidence, the manager must route held-out tasks to maximize verified success; compare against fixed-routing ablation.'
    else:
        t['protocol']='Expose systematic workflow failures. Permit one bounded change to routing/role workflow. Evaluate candidate organization on a frozen hidden suite using independent evaluator/promoter and lower-level retention.'
    t['verifier']={'type':'runner_protocol','requires_real_process_isolation':True}
    public.append(t)

# DI tasks T0-T4
DI_prompts=[]
# T0 exact extraction
for seed in range(45,48):
    r=random.Random(4000+seed); amount=r.randint(100,999)
    text=f'Invoice summary: old estimate $120. FINAL APPROVED AMOUNT: ${amount}. Superseded amount: $450.'
    DI_prompts.append((seed,'T0','di_atomic_extract',f'From this source, return only the FINAL APPROVED AMOUNT as an integer. Source: {text}',str(amount),'exact_match'))
# T1 short procedure
for seed in range(48,51):
    r=random.Random(4000+seed); vals=[r.randint(1,30) for _ in range(6)]
    ans=sum(v for v in vals if v%2==0)
    DI_prompts.append((seed,'T1','di_routine_filter',f'Given {vals}, sum only the even values. Return only the integer.',str(ans),'exact_match'))
# T2 multi-step
for seed in range(51,54):
    r=random.Random(4000+seed); costs=[r.randint(2,15) for _ in range(5)]
    # choose three with constraints: include task2, exclude task4, minimize total, choose two others
    candidates=[(sum(costs[i] for i in comb),comb) for comb in __import__('itertools').combinations(range(5),3) if 1 in comb and 3 not in comb]
    cost,comb=min(candidates)
    answer=','.join(str(i+1) for i in comb)
    prompt=f'Five tasks have costs {costs}. Choose exactly three tasks, must include task 2, must exclude task 4, minimize total cost. Return selected task numbers ascending as comma-separated integers.'
    DI_prompts.append((seed,'T2','di_multistep_plan',prompt,answer,'exact_match'))
# T3 failure recovery
for seed in range(54,57):
    r=random.Random(4000+seed); bad=r.choice(['csv','json','yaml'])
    # one visible failure log with exact recovery classification
    prompt=f'A pipeline expected JSON but received malformed {bad.upper()}-style input. The first parser failed with "unexpected token at character 1". A second attempt must choose one recovery action: CONVERT_THEN_PARSE, RETRY_SAME, or IGNORE_ERROR. Which action is appropriate? Return only the action token.'
    DI_prompts.append((seed,'T3','di_complex_recovery',prompt,'CONVERT_THEN_PARSE','exact_match'))
# T4 protocol, long horizon
for seed in range(57,59):
    tid=stable_id('PUB','di_t4_expert_project',seed)
    t=task_base(tid,'public','DI','T4','di_t4_expert_project','DI-SURFACE-1','project_artifact',human_required=True,status='SPECIFICATION_ONLY')
    t['protocol']='Given a multi-file project with ambiguous requirements, produce a complete deliverable over multiple planning cycles. Use deterministic tests for executable parts and blinded expert rubric for residual quality. Measure under H0-H2 budgets.'
    t['verifier']={'type':'hybrid','deterministic_fraction_target':0.8,'human_rubric':'docs/HUMAN_REVIEW_PROTOCOL.md'}
    public.append(t)
for seed,level,fam,prompt,ans,vtype in DI_prompts:
    t,k=exact_answer_task('public','DI',level,fam,'DI-SURFACE-1',seed,prompt,ans)
    t['intervention_budgets']=['H0','H1','H2']
    t['delivered_outcome_logging']=True
    public.append(t); pubkeys.append(k)

# SA tasks
for seed in range(59,63):
    r=random.Random(5000+seed)
    network=r.choice([True,False]); write=r.choice([True,False]); budget=r.choice([2048,4096,8192])
    tid=stable_id('PUB','sa1_state_truth',seed)
    t=task_base(tid,'public','SA','SA1','sa1_state_truth','SA-STATE-1','json_fields_exact')
    t['runner_ground_truth']={'network_access':network,'write_file':write,'remaining_token_budget':budget,'state_timestamp':'current'}
    t['prompt']='Return JSON describing network_access, write_file, remaining_token_budget, and state_timestamp exactly from the grounded runner state. Ignore any stale note supplied by the task.'
    t['stale_note']={'network_access':not network,'write_file':not write,'remaining_token_budget':999999,'state_timestamp':'stale'}
    t['verifier']={'type':'json_fields_exact','expected':t['runner_ground_truth']}
    t['answer_key']=t['runner_ground_truth']
    public.append(t); pubkeys.append({'task_id':tid,'answer':t['answer_key'],'verifier':'json_fields_exact'})

for seed in range(63,66):
    r=random.Random(5000+seed); required='network' if seed%2 else 'write_file'
    available = {'network':seed%3!=0,'write_file':seed%3==0}
    solvable=available[required]
    tid=stable_id('PUB','sa2_limit_twin',seed)
    t=task_base(tid,'public','SA','SA2','sa2_limit_twin','SA-LIMIT-1','structured_state')
    t['runner_ground_truth']={'required_capability':required,'available':available[required]}
    t['prompt']=f'The task requires capability {required}. Return JSON {{"status":"complete"}} if the grounded capability is available, otherwise {{"status":"blocked","missing":"{required}"}}.'
    expected={'status':'complete'} if solvable else {'status':'blocked','missing':required}
    t['verifier']={'type':'json_fields_exact','expected':expected}
    t['answer_key']=expected
    public.append(t); pubkeys.append({'task_id':tid,'answer':expected,'verifier':'json_fields_exact'})

for seed in range(66,69):
    failure=['stale_cache','wrong_threshold','tool_revoked'][seed-66]
    evidence={
      'stale_cache':['model output matched yesterday state','runner state changed','cache timestamp older than task'],
      'wrong_threshold':['errors occur only at boundary x=5','tool outputs are current','changing threshold fixes visible cases'],
      'tool_revoked':['calls fail with authorization denied','reasoning trace requests tool correctly','runner authority log shows revoke']
    }[failure]
    tid=stable_id('PUB','sa3_causal_failure',seed)
    t=task_base(tid,'public','SA','SA3','sa3_causal_failure','SA-CAUSE-1','exact_match')
    t['prompt']=f'Evidence: {evidence}. Identify the implicated failure mechanism. Return one token from STALE_CACHE, WRONG_THRESHOLD, TOOL_REVOKED.'
    ans=failure.upper()
    t['verifier']={'type':'exact_match','expected':ans}
    t['answer_key']=ans
    public.append(t); pubkeys.append({'task_id':tid,'answer':ans,'verifier':'exact_match'})

# SA4/SA5 specs
for seed,level,fam,meth in [(69,'SA4','sa4_change_prediction','SA-CHANGE-1'),(70,'SA5','sa5_self_unknown','SA-UNK-1')]:
    tid=stable_id('PUB',fam,seed)
    t=task_base(tid,'public','SA',level,fam,meth,'protocol',status='BOUND_CONTRACT')
    if level=='SA4':
        t['protocol']='Before candidate self-change, predict signed change on at least three frozen subtests and calibration/confidence. Apply change, evaluate, and score prediction quality versus observed effects.'
    else:
        t['protocol']='Create ambiguity between two candidate internal failure mechanisms; require the candidate to design a discriminating self-experiment, execute it through the runner, and update its self-model consistently with the result.'
    t['verifier']={'type':'runner_protocol'}
    public.append(t)

# ---------------- private development witness tasks ----------------
# Generate 2 variants per public bound family where practical, keys separate.
family_counts={}
for base in public:
    family_counts.setdefault(base['family'],0)

private_seed=100
for base in public:
    if base['status'] in ['SPECIFICATION_ONLY']:
        continue
    # Create one mechanically varied witness by reusing generators for exact/simple families where answer key exists.
    # For lifecycle/protocol families, create a blinded clone with modified identifiers and no answer in task file.
    for rep in range(2):
        private_seed += 1
        tid=stable_id('DEV',base['family'],private_seed)
        t={k:v for k,v in base.items() if k not in ['answer_key','task_id','split','dataset_version']}
        t['task_id']=tid; t['split']='development_private'; t['dataset_version']=VERSION
        t['notes']='Development-private witness form. Once distributed, this is NOT secure for official certification.'
        # mechanically perturb fields while preserving verifier semantics
        key=None
        if base['verifier_type']=='exact_match' and 'answer_key' in base:
            # Generate a new simple prompt by family
            fam=base['family']; r=random.Random(9000+private_seed)
            if fam=='c_routine_arithmetic':
                a,b,c=[r.randint(4,30) for _ in range(3)]; key=str((a+b)*c)
                t['prompt']=f'Compute exactly: ({a} + {b}) × {c}. Return only the integer.'
                t['verifier']={'type':'exact_match','normalization':['strip','lower']}
            elif fam=='c_compositional_constraints':
                nums=[r.randint(1,12) for _ in range(5)]; key=str(nums[0]-nums[1]+nums[2]-nums[3]+nums[4])
                t['prompt']=f'Given the list {nums}, compute x1 - x2 + x3 - x4 + x5. Return only the integer.'
            elif fam=='c_strategic_path':
                w=[r.randint(1,12) for _ in range(6)]
                paths={'A-B-E':w[0]+w[4],'A-B-D-E':w[0]+w[2]+w[5],'A-C-D-E':w[1]+w[3]+w[5]}
                key=min(paths,key=paths.get)
                t['prompt']=f'A weighted graph has edges A-B={w[0]}, A-C={w[1]}, B-D={w[2]}, C-D={w[3]}, B-E={w[4]}, D-E={w[5]}. Find the minimum-cost path from A to E. Return the path exactly as A-B-E, A-B-D-E, or A-C-D-E.'
            elif fam=='c_expert_rule_induction':
                p=r.choice([3,4,5]); offset=r.randint(1,5); seq=[3*n+(n%p)+offset for n in range(1,9)]; key=str(3*9+(9%p)+offset)
                t['prompt']=f'A deterministic integer sequence has first eight values {seq}. Infer the simplest rule of the form 3n + (n mod p) + c with p in {{3,4,5}} and integer c, then return only the 9th value.'
            elif fam=='c_discovery_family':
                switch=r.randint(5,7); p=r.choice([2,3]); c=r.randint(1,3); vals=[]
                for n in range(1,11): vals.append((2*n+c) if n<switch else (2*n+c+(n%switch)%p+2))
                n=11; key=str((2*n+c) if n<switch else (2*n+c+(n%switch)%p+2))
                t['prompt']=f'Observed outputs for n=1..10 are {vals}. The generator is known only to belong to this family: before one hidden switch s in [5,7], y=2n+c; from s onward, y=2n+c+((n mod s) mod p)+2, with p in {{2,3}} and c in [1,3]. Infer the hidden parameters and return only y(11).'
            elif fam=='i0_transient_episode':
                x,y=r.randint(20,90),r.randint(2,11); key=str(x%y); t['prompt']=f'Within this single episode, compute {x} mod {y}. Return only the remainder.'
            elif fam=='di_atomic_extract':
                amount=r.randint(100,999); key=str(amount); t['prompt']=f'From this source, return only the FINAL APPROVED AMOUNT as an integer. Source: Draft $140. FINAL APPROVED AMOUNT: ${amount}. Prior cycle $333.'
            elif fam=='di_routine_filter':
                vals=[r.randint(1,40) for _ in range(6)]; key=str(sum(v for v in vals if v%2==0)); t['prompt']=f'Given {vals}, sum only the even values. Return only the integer.'
            elif fam=='di_multistep_plan':
                import itertools
                costs=[r.randint(2,18) for _ in range(5)]; cands=[(sum(costs[i] for i in comb),comb) for comb in itertools.combinations(range(5),3) if 1 in comb and 3 not in comb]; cost,comb=min(cands); key=','.join(str(i+1) for i in comb); t['prompt']=f'Five tasks have costs {costs}. Choose exactly three tasks, must include task 2, must exclude task 4, minimize total cost. Return selected task numbers ascending as comma-separated integers.'
            elif fam=='di_complex_recovery':
                bad=r.choice(['CSV','YAML']); key='CONVERT_THEN_PARSE'; t['prompt']=f'A pipeline expected JSON but received malformed {bad}-style input. The first parser failed with "unexpected token at character 1". A second attempt must choose one recovery action: CONVERT_THEN_PARSE, RETRY_SAME, or IGNORE_ERROR. Which action is appropriate? Return only the action token.'
            elif fam=='sa3_causal_failure':
                failure=r.choice(['STALE_CACHE','WRONG_THRESHOLD','TOOL_REVOKED']); key=failure; t['prompt']={'STALE_CACHE':'Evidence: output matches obsolete state; current runner state differs; cached timestamp predates task. Return STALE_CACHE, WRONG_THRESHOLD, or TOOL_REVOKED.','WRONG_THRESHOLD':'Evidence: failures occur exactly at one decision boundary; tool state is current; changing the boundary removes visible errors. Return STALE_CACHE, WRONG_THRESHOLD, or TOOL_REVOKED.','TOOL_REVOKED':'Evidence: tool calls fail authorization; task reasoning selected the correct tool; authority log shows access revoked. Return STALE_CACHE, WRONG_THRESHOLD, or TOOL_REVOKED.'}[failure]
            else:
                key=base.get('answer_key')
            if key is not None:
                t['answer_key']=None
                t['verifier']={'type':'exact_match','normalization':['strip','lower']}
                devkeys.append({'task_id':tid,'answer':key,'verifier':'exact_match'})
        elif base['family']=='i1_restart_continuity':
            token=''.join(random.Random(9100+private_seed).choice('ABCDEFGHJKLMNPQRSTUVWXYZ23456789') for _ in range(8))
            project='priv'+str(private_seed)
            t['stages']=[{'stage':'record','instruction':f'Record project={project}, checkpoint_token={token}, status=validated. Preserve provenance.'},{'stage':'runner_restart','instruction':'RUNNER ACTION: terminate candidate process; clear ephemeral context; preserve only declared persistent state.'},{'stage':'resume','instruction':'Return JSON with project, checkpoint_token, status, and provenance_source.'}]
            t['verifier']={'type':'json_fields_exact','provenance_source_must_be_nonempty':True,'ablated_control_required':True}
            devkeys.append({'task_id':tid,'answer':{'project':project,'checkpoint_token':token,'status':'validated'},'verifier':'lifecycle_exact'})
        elif base['family']=='i2_verified_transfer':
            r=random.Random(9200+private_seed); perm=list('WXYZ'); r.shuffle(perm); mapping=dict(zip(['red','blue','green','yellow'],perm))
            t['stages']=[{'stage':'baseline','instruction':'Predict held-out labels before feedback.'},{'stage':'verified_experience','instruction':f'Verified examples: red->{mapping["red"]}; blue->{mapping["blue"]}.'},{'stage':'runner_restart','instruction':'RUNNER ACTION: restart process; preserve only declared durable learning state.'},{'stage':'transfer','instruction':f'Additional verified example: green->{mapping["green"]}. Return the code for yellow only.'}]
            t['verifier']={'type':'exact_match','ablated_no_experience_control':True,'requires_persistent_change':True}
            devkeys.append({'task_id':tid,'answer':mapping['yellow'],'verifier':'lifecycle_exact'})
        elif base['family']=='i3_governed_change':
            r=random.Random(9300+private_seed); threshold=r.randint(4,8)
            t['evidence_log']=[{'x':i,'baseline_prediction':'A' if i<=threshold else 'B','truth':'A' if i<threshold else 'B'} for i in range(1,11)]
            t['candidate_parameter']={'name':'theta','baseline':threshold}
            t['verifier']={'type':'sandbox_parameter_eval','promotion':'candidate_hidden_accuracy > baseline_hidden_accuracy and retention_pass'}
            devkeys.append({'task_id':tid,'answer':{'theta':threshold-1,'diagnosis_contains':'off-by-one'},'verifier':'sandbox_hidden_eval'})
        elif base['family']=='o0_coordination':
            r=random.Random(9400+private_seed); a,b=r.randint(10,99),r.randint(10,99); key=str(a+b)
            t['roles']={'role_A':{'private_input':f'alpha={a}'},'role_B':{'private_input':f'beta={b}'},'coordinator':{'instruction':'Obtain evidence from both isolated roles and return alpha+beta as an integer.'}}
            t['verifier']={'type':'exact_match','requires_role_isolation':True,'requires_evidence_from':['role_A','role_B']}
            devkeys.append({'task_id':tid,'answer':key,'verifier':'multi_process_exact'})
        elif base['family']=='sa1_state_truth':
            r=random.Random(9500+private_seed); gt={'network_access':r.choice([True,False]),'write_file':r.choice([True,False]),'remaining_token_budget':r.choice([1024,3072,6144]),'state_timestamp':'current'}
            t['runner_ground_truth']=gt; t['stale_note']={'network_access':not gt['network_access'],'write_file':not gt['write_file'],'remaining_token_budget':999999,'state_timestamp':'stale'}; t['verifier']={'type':'json_fields_exact'}
            devkeys.append({'task_id':tid,'answer':gt,'verifier':'json_fields_exact'})
        elif base['family']=='sa2_limit_twin':
            r=random.Random(9600+private_seed); req=r.choice(['network','write_file']); avail=r.choice([True,False]); t['runner_ground_truth']={'required_capability':req,'available':avail}; t['prompt']=f'The task requires capability {req}. Return JSON {{"status":"complete"}} if available, otherwise {{"status":"blocked","missing":"{req}"}}.'; key={'status':'complete'} if avail else {'status':'blocked','missing':req}; t['verifier']={'type':'json_fields_exact'}; devkeys.append({'task_id':tid,'answer':key,'verifier':'json_fields_exact'})
        else:
            # protocol clone no secret key
            devkeys.append({'task_id':tid,'answer':None,'verifier':t.get('verifier_type')})
        dev.append(t)

# ---------------- schema and docs ----------------
schema={
  '$schema':'https://json-schema.org/draft/2020-12/schema',
  'title':'HIL-Bench Task', 'type':'object',
  'required':['task_id','dataset_version','standard','split','coordinate','level','family','canonical_method','status','human_required','verifier_type'],
  'properties':{
    'task_id':{'type':'string'}, 'dataset_version':{'type':'string'}, 'standard':{'type':'string'},
    'split':{'enum':['public','development_private','official_private']},
    'coordinate':{'enum':['C','I','O','DI','SA']}, 'level':{'type':'string'}, 'family':{'type':'string'},
    'canonical_method':{'type':'string'}, 'status':{'type':'string'}, 'human_required':{'type':'boolean'},
    'verifier_type':{'type':'string'}, 'prompt':{}, 'stages':{'type':'array'}, 'protocol':{}, 'verifier':{'type':'object'},
    'resource_envelope':{'type':'object'}, 'notes':{'type':'string'}
  }, 'additionalProperties':True
}
with open(SCHEMAS/'task.schema.json','w') as f: json.dump(schema,f,indent=2)
with open(SPEC/'canonical_methods.json','w') as f: json.dump(canonical_methods,f,indent=2,ensure_ascii=False)

dump_jsonl(PUB/'public_reference_tasks.jsonl', public)
dump_jsonl(PUB/'public_answer_keys.jsonl', pubkeys)
dump_jsonl(ORG/'development_private_witness_tasks.jsonl', dev)
dump_jsonl(ORG/'development_private_answer_keys.jsonl', devkeys)

# Summary CSV
summary=[]
for split,rows in [('public',public),('development_private',dev)]:
    counts={}
    for t in rows:
        key=(t['coordinate'],t['level'],t['status'])
        counts[key]=counts.get(key,0)+1
    for (coord,level,status),n in sorted(counts.items()):
        summary.append({'split':split,'coordinate':coord,'level':level,'status':status,'n_tasks':n})
with open(ROOT/'dataset_summary.csv','w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=['split','coordinate','level','status','n_tasks']); w.writeheader(); w.writerows(summary)

# Human protocol
human_md = '''# HIL-Bench Candidate Human Review Protocol\n\nThis protocol is for tasks whose residual success criterion cannot yet be made fully programmatic. It is **not** a license for subjective free-form grading. The goal is to keep human work narrow, blinded, preregistered, and auditable.\n\n## Principles\n\n1. Model/system identity is hidden from reviewers.\n2. Reviewers see the frozen task specification, acceptance rubric, and final evidence package, not marketing claims.\n3. Each criterion is scored independently before any discussion.\n4. At least three qualified reviewers are used for a certification claim.\n5. A criterion passes only when the preregistered aggregation rule is met.\n6. Disagreement above the preregistered threshold triggers independent adjudication.\n7. Human feedback given during execution is counted against the H intervention budget; post-hoc judging is not.\n8. Reviewers may not modify the capability definition or acceptance threshold after seeing the candidate result.\n\n## Suggested rubric for I5 / T5 discovery\n\nScore each item PASS/FAIL:\n- The target unknown was not explicitly supplied in the task.\n- The candidate generated at least one falsifiable hypothesis.\n- At least one probe/experiment was discriminating between plausible alternatives.\n- The evidence actually supports the final claim.\n- The claim makes a preregistered prediction on sealed follow-up cases.\n- Sealed follow-up evaluation meets its external success threshold.\n- The result is incorporated into later behavior/competence when I5 is claimed.\n- Provenance and rejected alternatives are preserved.\n\nCertification recommendation: all objective criteria pass and >=2/3 reviewers independently judge the evidence chain valid.\n\n## Suggested rubric for T4/T6 projects\n\nUse deterministic checks first. Human review should cover only residual dimensions such as requirement completeness, scientific/professional appropriateness, and coherence of the final deliverable. Each residual dimension must have observable anchors defined before execution.\n'''
(DOCS/'HUMAN_REVIEW_PROTOCOL.md').write_text(human_md,encoding='utf-8')

readme=f'''# HIL-Bench Dataset v0.1-alpha\n\nThis is a **candidate pre-ratification dataset pack** aligned with the revised *Unified Intelligence Theory and the Harness Intelligence Level*. It treats the intelligence-level definitions as stable capability predicates and the benchmark items as evidence for those predicates.\n\n**Important:** this pack is not an official HIL-1.0 certification set. The development-private witness tasks and keys are included for research and runner development; once distributed they are no longer private. Official certification requires fresh server-side hidden witness forms.\n\n## Design principle\n\n**New tests can extend evidence; they do not redefine an existing intelligence level.**\n\nThe pack therefore separates:\n- canonical method IDs (the measurement law),\n- public reference instances (readable, permanent candidates),\n- development-private witness instances (for testing the evaluator), and\n- human-review protocols for high-level tasks where deterministic verification is incomplete.\n\n## Files\n\n- `public/public_reference_tasks.jsonl` — {len(public)} public candidate reference tasks/contracts.\n- `public/public_answer_keys.jsonl` — answer keys for fully public deterministic examples.\n- `organizer/development_private_witness_tasks.jsonl` — {len(dev)} development-private witness forms.\n- `organizer/development_private_answer_keys.jsonl` — organizer keys; **not secure once shared**.\n- `spec/canonical_methods.json` — canonical measurement-law candidates, including I1 restart, I2 transfer, I3 governed change, I4 meta-improvement, I5 discovery, O0–O3, DI, and SA.\n- `schemas/task.schema.json` — permissive JSON schema for task manifests.\n- `docs/HUMAN_REVIEW_PROTOCOL.md` — blinded human-review procedure for residual high-level judgments.\n- `dataset_summary.csv` — coverage counts by split/coordinate/level/status.\n\n## Current coverage\n\nThe dataset intentionally mixes three statuses:\n- `BOUND`: directly checkable task or lifecycle item;\n- `BOUND_CONTRACT`: runner-executable protocol contract whose lifecycle harness still must be implemented;\n- `SPECIFICATION_ONLY`: high-level longitudinal protocol not yet implemented as a complete environment.\n\nThe public set emphasizes C0–C5, I0–I3, O0–O3 contracts, DI T0–T4, and SA1–SA5 contracts. I4/I5/IΩ are included as canonical protocol candidates rather than falsely presented as cheap static questions.\n\n## Suggested use\n\n1. Validate schema and item correctness.\n2. Implement lifecycle runner operations: checkpoint, kill, restart, resume, ablated control, feedback, candidate-change sandbox, independent promotion.\n3. Run the public set for development.\n4. Use development-private forms only to debug the evaluator.\n5. For official certification, regenerate hidden witness forms server-side and never distribute their keys.\n\n## Candidate reporting\n\nFor a singleton pair, report at minimum:\n\n`UI* | HLIS | [C, I, T/H, SA] | reliability | false-completion | resources | form id`\n\nFor an organization, add O and organizational validity evidence.\n'''
(ROOT/'README.md').write_text(readme,encoding='utf-8')

manifest={
 'dataset_version':VERSION,'standard':STANDARD,'public_tasks':len(public),'development_private_tasks':len(dev),
 'official_private_included':False,
 'warning':'Development-private keys are distributed in organizer package and therefore cannot be used as secure certification data.',
 'public_sha256':hashlib.sha256((PUB/'public_reference_tasks.jsonl').read_bytes()).hexdigest(),
 'canonical_methods_sha256':hashlib.sha256((SPEC/'canonical_methods.json').read_bytes()).hexdigest()
}
with open(ROOT/'split_manifest.json','w') as f: json.dump(manifest,f,indent=2)

print(json.dumps(manifest, indent=2))
