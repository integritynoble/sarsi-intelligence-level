# HIL-Bench Candidate Human Review Protocol

This protocol is for tasks whose residual success criterion cannot yet be made fully programmatic. It is **not** a license for subjective free-form grading. The goal is to keep human work narrow, blinded, preregistered, and auditable.

## Principles

1. Model/system identity is hidden from reviewers.
2. Reviewers see the frozen task specification, acceptance rubric, and final evidence package, not marketing claims.
3. Each criterion is scored independently before any discussion.
4. At least three qualified reviewers are used for a certification claim.
5. A criterion passes only when the preregistered aggregation rule is met.
6. Disagreement above the preregistered threshold triggers independent adjudication.
7. Human feedback given during execution is counted against the H intervention budget; post-hoc judging is not.
8. Reviewers may not modify the capability definition or acceptance threshold after seeing the candidate result.

## Suggested rubric for I5 / T5 discovery

Score each item PASS/FAIL:
- The target unknown was not explicitly supplied in the task.
- The candidate generated at least one falsifiable hypothesis.
- At least one probe/experiment was discriminating between plausible alternatives.
- The evidence actually supports the final claim.
- The claim makes a preregistered prediction on sealed follow-up cases.
- Sealed follow-up evaluation meets its external success threshold.
- The result is incorporated into later behavior/competence when I5 is claimed.
- Provenance and rejected alternatives are preserved.

Certification recommendation: all objective criteria pass and >=2/3 reviewers independently judge the evidence chain valid.

## Suggested rubric for T4/T6 projects

Use deterministic checks first. Human review should cover only residual dimensions such as requirement completeness, scientific/professional appropriateness, and coherence of the final deliverable. Each residual dimension must have observable anchors defined before execution.
