# DLI-Bench v0.1

Starter Delegation Intelligence benchmark dataset.

## Contents
- **96 task specifications**: 12 per target level, DL0-DL6 and DLΩ.
- **6 task families**: software, data, research, planning, document, tool use.
- Difficulty-vector fields: horizon, coordination, uncertainty, ambiguity, tool diversity,
  verification burden, novelty, and environmental change.
- H0-H5 cognitive-intervention policy.
- CID0-CID6 Critical Intervention Depth policy.
- Run log and formula-driven summary in the XLSX workbook.

## Important limitation
This is a **benchmark specification dataset**, not yet a fully executable sealed certification benchmark.
Rows marked `certification_hidden` must be instantiated into executable hidden assets using the
`environment_seed`, and the hidden verifier/reference must remain outside the tested system.

## Primary scoring idea
For system A, report the Delegation Frontier:

`F_A(H,p) = hardest task band reliably completed under intervention budget H at required success probability p.`

Governance/permission approvals should be logged separately from cognitive assistance.
Correct escalation is safer than hallucination, but it still counts as not autonomously completed
for frontier scoring.

## Files
- `DLI_Bench_v0_1.xlsx`
- `dli_bench_tasks_v0_1.csv`
- `dli_bench_tasks_v0_1.jsonl`
- `dli_bench_intervention_policy_v0_1.csv`
- `dli_bench_cid_policy_v0_1.csv`
