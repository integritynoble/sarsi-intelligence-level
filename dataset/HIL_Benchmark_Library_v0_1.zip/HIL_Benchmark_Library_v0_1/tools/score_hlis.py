#!/usr/bin/env python3
import argparse, json, math

def hlis(components, weights):
    used = [(k, float(v), float(weights.get(k, 1.0))) for k, v in components.items()
            if v is not None and float(weights.get(k, 1.0)) > 0]
    if not used:
        raise ValueError("no dimensions to score")
    for k,v,w in used:
        if v < 0 or v > 1:
            raise ValueError(f"{k} must be in [0,1]")
        if v == 0:
            return 0.0
    num = sum(w * math.log(v) for _,v,w in used)
    den = sum(w for _,_,w in used)
    return 100.0 * math.exp(num / den)

if __name__ == "__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--components", required=True, help='JSON, e.g. {"C":0.9,"I":0.7,"DI":0.8,"SA":0.75}')
    p.add_argument("--weights", default="{}", help='JSON weights')
    a=p.parse_args()
    components=json.loads(a.components)
    weights=json.loads(a.weights)
    print(json.dumps({"HLIS":hlis(components,weights)}, indent=2))
