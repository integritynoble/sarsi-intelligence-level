#!/usr/bin/env python3
from pathlib import Path
import json, csv, sys

ROOT=Path(__file__).resolve().parents[1]

def count_jsonl(path):
    n=0
    ids=set()
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip(): continue
        obj=json.loads(line)
        bid=obj.get("benchmark_id")
        if bid in ids: raise ValueError(f"duplicate benchmark_id {bid}")
        ids.add(bid); n+=1
    return n

def main():
    native=count_jsonl(ROOT/"data"/"hil_native_tasks.jsonl")
    delegation=count_jsonl(ROOT/"data"/"delegation_plane_tasks.jsonl")
    external=sum(1 for _ in csv.DictReader((ROOT/"data"/"external_benchmark_registry.csv").open(encoding="utf-8")))
    assert native==160, native
    assert delegation==64, delegation
    assert external>=20, external
    print(json.dumps({"ok":True,"native_tasks":native,"delegation_tasks":delegation,"external_benchmarks":external}))

if __name__=="__main__":
    main()
