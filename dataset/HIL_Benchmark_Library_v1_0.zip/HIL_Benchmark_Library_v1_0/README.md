# HIL Benchmark Library v1.0

Comprehensive benchmark library for Harness-Level Intelligence aligned to HIL framework v1.5.1.

## Coverage
- C-Bench: Cognitive Intelligence C.
- I-Bench: Individual Intelligence I with long-term memory embedded.
- O-Bench: Organizational Intelligence O.
- DI-Bench: T0-TΩ × H0-H5 delivered-and-correct delegation.
- SA-Bench: evidence-grounded self-awareness.
- U-Bench: cumulative U0-UΩ gates and retention.
- HIL-Ladder: same frozen model across HG0→HGΩ.
- VR-Bench: verification responsiveness.
- HDS-Bench: harness design gain under hidden external evaluation.

Native task specifications: 666
Delegation task/H cells before repetitions: 960
External registry entries: 24
Bound development examples: 16

Primary delegation surface: S_del(T,H)=P(delivered=1 AND verifier_pass=1)
Frontier: F(H,p)=max{T:S_del(T,H)>=p}
HLIS=100*exp(sum(alpha_d*ln(A_d))/sum(alpha_d))
HSC_m(k)=HLIS(m,HG_k)

Long context does not certify I1. Formal I1+ requires genuine restart/context discontinuity.
Bound starter tasks are development examples, not hidden certification tasks.
HG3-HGΩ formal certification requires sealed environments, longitudinal trials, independent verifier ownership and protected hidden assets.
