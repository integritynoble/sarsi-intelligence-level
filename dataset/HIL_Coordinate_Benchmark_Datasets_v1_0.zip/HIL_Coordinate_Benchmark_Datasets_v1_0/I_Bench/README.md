# I-Bench
Measures Individual Intelligence I0-IΩ with long-term memory embedded as its temporal substrate.
I1 requires genuine restart/cross-session continuity. I2 requires experience-driven later behavior change.
I3+ is protocol-bound because formal certification requires sealed replay, external evaluator/promoter,
rollback/version lineage, and longitudinal evidence. Public examples are development tasks, not secure certification.
