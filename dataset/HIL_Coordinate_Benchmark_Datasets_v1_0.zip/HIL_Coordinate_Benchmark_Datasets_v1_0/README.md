# HIL Coordinate Benchmark Datasets v1.0

This package operationalizes the six directly measured coordinates of the HIL/Unified Intelligence framework:
**C, I, O, T, H, SA**. Delegation Intelligence is derived from the cross-product **T × H × p**.

## Dataset sizes
- C-Bench: 320 items
- I-Bench: 168 longitudinal/protocol items
- O-Bench: 126 multi-agent protocol items
- T-Bench: 256 calibrated task specifications
- H-Bench: 180 intervention-label episodes
- SA-Bench: 192 grounded self-model items
- GUI Perception subset: 32 image-backed C items
- DI integration cells: 1536

## Important framework mappings
- Long-term memory is inside I.
- GUI Perception GP is inside C.
- Visual/interface complexity P_vis is inside T.
- Computer-task completion is tested in DI using T×H×p.
- T and H are not extra intelligence dimensions; they characterize delegated work and human dependence.

## Certification status
The package contains bound development instances and protocol-bound higher-level tasks.
Formal I3+, O3+, T5+, U5+ and open-ended certification must use hidden/sealed environments, independent verifiers,
longitudinal runs, and evaluator/promoter separation. Do not treat the public keys in this package as a secure certification set.

## Item-validity requirements
Before attributing failures to systems:
1. Run specification-key consistency tests.
2. Audit identical cross-tier errors.
3. Prefer graded scoring with separated failure modes.
4. Report per-coordinate headroom and saturation.
