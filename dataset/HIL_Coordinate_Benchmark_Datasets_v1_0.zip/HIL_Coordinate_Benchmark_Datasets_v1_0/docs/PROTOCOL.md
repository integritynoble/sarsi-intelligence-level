# Coordinate Benchmark Protocol

## C
Use minimal standardized harness conditions. C measures problem solving, not persistence. GP is a diagnostic subscale inside C.

## I
I1+ requires genuine cross-session/process discontinuity. I2+ must demonstrate behavior changed by verified prior experience.
I3+ requires external evaluation/promotion of candidate cognitive changes. I4+ requires multiple improvement generations.
I5+ requires novelty and reproducibility.

## O
Use real separate roles/processes with evidence-bearing communication. One-model prompt role-play is not organizational evidence.
O3+ requires protected evaluator/promoter separation.

## T
T is a calibrated task property. Publish the full difficulty vector:
(L,K,U,A,X,V,N,E,P_vis). Avoid hidden tricks as a substitute for difficulty.

## H
Log H0-H5, maximum CID, intervention count, human cognitive minutes, and governance approvals separately.
Governance approval is not cognitive help unless it supplies strategy or information.

## SA
Use external machine state as ground truth. Unsupported self-description receives no credit.

## DI integration
Primary delivered-success surface:
S_del(T,H)=P(delivered=1 AND verifier_pass=1 | T,H)
Report false completion, held-back invalid, false rejection, and F(H,p) beside any aggregate.

## Instrument validity
Each item family must pass specification-key consistency. Identical cross-tier failures trigger concordance audit.
Report headroom/saturation for every coordinate.
