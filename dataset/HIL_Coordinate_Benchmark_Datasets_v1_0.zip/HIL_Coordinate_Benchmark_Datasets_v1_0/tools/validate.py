#!/usr/bin/env python3
import csv, sys, os, json
root=sys.argv[1] if len(sys.argv)>1 else "."
files=[
("C_Bench/c_bench.csv","C"),("I_Bench/i_bench.csv","I"),("O_Bench/o_bench.csv","O"),
("T_Bench/t_bench.csv","T"),("H_Bench/h_bench.csv","H"),("SA_Bench/sa_bench.csv","SA")]
errors=[]
total=0
for rel,coord in files:
    p=os.path.join(root,rel)
    with open(p,newline="",encoding="utf-8") as f:
        rows=list(csv.DictReader(f))
    total+=len(rows)
    ids=[r["item_id"] for r in rows]
    if len(ids)!=len(set(ids)): errors.append(f"{coord}: duplicate ids")
    if any(r.get("coordinate")!=coord for r in rows): errors.append(f"{coord}: coordinate mismatch")
print(json.dumps({"coordinate_items":total,"errors":errors},indent=2))
raise SystemExit(1 if errors else 0)
