# HIL Coordinate Benchmark Datasets v1.1

Aligned to the HIL/Unified Intelligence framework v1.8.

## Core measured coordinates
C, I, O, T, H, SA. Delegation Intelligence is derived from T × H × p.

## New in v1.1: independent Memory Capability
Memory Capability **M** is now benchmarked independently as a **supporting coordinate**.
It is not a sixth conceptual intelligence family and is excluded from default HLIS.

Formal relationship:
`I(A) >= I_n  =>  M(A) >= mu_n`
The converse does not hold.

This means a system may validly be **I1/M4**, for example: excellent durable/self-managing memory
without adaptive learning or self-improvement.

## Dataset sizes
- C-Bench: 320
- I-Bench: 168
- O-Bench: 126
- T-Bench: 256
- H-Bench: 180
- SA-Bench: 192
- M-Bench (supporting): 168
- DI T×H cells: 1536
- GUI Perception image subset: 32

## I prerequisites
I0>=M0; I1>=M1; I2>=M3; I3>=M4; I4>=M4; I5>=M5; IΩ>=M5.
Require MΩ only when memory-architecture evolution itself is part of the IΩ claim.

## Validity
Specification-key consistency, cross-tier concordance audit, graded scoring/failure modes,
and per-coordinate headroom remain mandatory.
